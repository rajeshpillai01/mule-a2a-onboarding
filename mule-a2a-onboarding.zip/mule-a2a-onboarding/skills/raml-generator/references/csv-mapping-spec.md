# CSV Mapping Specification Format

The mapping specification CSV drives data type and example generation. The agent reads the **source columns** to extract field definitions for the RAML spec.

## Expected CSV Columns

The CSV must have a header row. The agent should detect columns by name (case-insensitive, partial match). Common column names:

| Column | Also known as | What it provides |
|---|---|---|
| Field Name | field_name, Source Field, Input Field Name, Path leaf | RAML property name |
| Data Type | data_type, Target Data Type, Input Data Type, Type | RAML property type |
| Description | desc, field_description | RAML property description |
| Required | mandatory, is_required | Whether the field is required (yes/true/1 = required) |
| Length | size, max_length, Absolute Character Length, Input Length | maxLength constraint for strings |
| Example | sample, example_value | Example value for the field |
| Enum Values | allowed_values, valid_values | Pipe-separated enum values (e.g., `PENDING\|CONFIRMED\|SHIPPED`) |
| Segment / Group | segment, record_type, Loop Hierarchies | Groups fields into nested objects or arrays |

## Type Mapping Rules

Map CSV data types to RAML types:

| CSV Type (case-insensitive) | RAML Type |
|---|---|
| `String`, `Text`, `Char`, `VARCHAR` | `string` |
| `Integer`, `Int`, `Number` (no decimals) | `integer` |
| `Decimal`, `Float`, `Double`, `Number` | `number` |
| `Boolean`, `Bool`, `Flag` | `boolean` |
| `Date` | `date-only` |
| `DateTime`, `Timestamp` | `datetime` |
| `Null`, empty | `string` (default, mark as not required) |

## Segment/Group Handling

When the CSV has a segment or group column:
1. Each unique segment value becomes a separate RAML data type
2. Fields within the same segment are properties of that type
3. If a segment is marked as "repeatable" or "array" in the description/hierarchy column, the parent type references it as `TypeName[]`
4. Nested segments (e.g., "Nested under X") become properties of the parent type

## Output Generation

For each segment/group (or for the flat list if no segments):

1. **RAML DataType file** (`data-types/<TypeName>.raml`):
   ```yaml
   #%RAML 1.0 DataType
   type: object
   description: <derived from segment name>
   properties:
     fieldName:
       type: <mapped RAML type>
       description: <from Description column or field name>
       required: <from Required column, default true>
       maxLength: <from Length column, if string>
       example: <from Example column or generated>
   ```

2. **JSON example file** (`examples/<type-name>.json`):
   Generate a valid JSON object using the Example column values. If no examples are provided, generate plausible values based on field name and type.

3. **JSON list example** (`examples/<type-name>-list.json`):
   Array of 2 example objects with varied values.

## Edge Cases

- If the CSV has no header row, treat the first row as headers
- If field names contain spaces, convert to camelCase for RAML property names
- If field names contain special characters, strip them
- If a field has `Null` type and no other info, make it an optional string
- Duplicate field names within a segment: append a numeric suffix
