# Roche Anypoint Exchange RAML Fragment Catalog

Organization ID: `7f34e134-ef86-4a88-a34a-368f44ff5920`

## Fragments

### 1. roche-resourcetypes (v1.0.17)

**Asset ID:** `roche-resourcetypes`
**Type:** `raml-fragment` (Library)
**Main file:** `roche-resourcetypes.raml`

Provides standard resource type patterns. Each resource type pre-wires success responses (from `roche-responsemessages`) and error responses (from `roche-faultmessages`).

| Resource Type | Use When |
|---|---|
| `healthcheck` | `/health` or `/status` endpoint |
| `record-sync` | Single-record CRUD, synchronous (201 on POST, 200/204 on PUT/PATCH) |
| `record-async` | Single-record CRUD, asynchronous (202 on POST/PUT/PATCH) |
| `record-request-success` | Single-record with request-body echoed in success response |
| `collection-sync` | Collection CRUD, synchronous |
| `collection-async` | Collection CRUD, asynchronous |
| `collection-request-success` | Collection with request-body echoed in success response |
| `collection-paged-sync` | Paginated collection, synchronous |
| `collection-paged-async` | Paginated collection, asynchronous |
| `collection-paged-request-success` | Paginated collection with request-body echoed |

**Template parameters required by resource types:**

For record types:
- `recordDisplayName`, `recordDescription` — display metadata
- `recordType`, `recordExample` — input body type and example
- `responseType` — media type (usually `application/json`)
- `outputType_200`, `outputExample_200` (for PUT/PATCH sync)
- `outputType_201`, `outputExample_201` (for POST sync)
- `outputType_202`, `outputExample_202` (for POST/PUT/PATCH async)
- `outputType_200_for_delete`, `outputExample_200_for_delete` (for DELETE)

For collection types (add these):
- `recordListDisplayName`, `recordListDescription`
- `recordListType`, `recordListExample`

For paged collection types (add these):
- `recordListPagedDisplayName`, `recordListPagedDescription`
- `recordListPagedType`, `recordListPagedExample`

---

### 2. roche-faultmessages (v1.0.5)

**Asset ID:** `roche-faultmessages`
**Type:** `raml-fragment` (Library)
**Main file:** `roche-faultmessages.raml`

Defines error traits for HTTP status codes: 400, 401, 403, 404, 405, 406, 407, 415, 429, 500, 501, 502, 503, 504.

**Fault data type** (`definitions/roche-api_fault.raml`):
```yaml
properties:
  statusCode: number
  statusType: string
  statusMessage: string
  statusDetails: string
  correlationId: string
```

Special cases:
- **429** uses `roche-api_fault_429.raml` (only `error: string`)
- **502** uses `roche-api_fault_502.raml` (plain `string` type, `application/java` media type)

Trait names: `err_400`, `err_401`, `err_403`, `err_404`, `err_405`, `err_406`, `err_407`, `err_415`, `err_429`, `err_500`, `err_501`, `err_502`, `err_503`, `err_504`

---

### 3. roche-responsemessages (v1.0.5)

**Asset ID:** `roche-responsemessages`
**Type:** `raml-fragment` (Trait)
**Main file:** `roche-responsemessages.raml`

Defines success response traits:

| Trait | Status | Body |
|---|---|---|
| `success_200` | 200 | `<<recordType>>` with `<<recordExample>>` |
| `success_200_for_delete` | 200 | `<<recordType>>` with `<<recordExample>>` |
| `updated_200` | 200 | `<<recordType>>` with `<<recordExample>>` |
| `success_201` | 201 | `<<recordType>>` with `<<recordExample>>` |
| `success_202` | 202 | `<<recordType>>` with `<<recordExample>>` |
| `nullvalue_204` | 204 | No body |
| `updated_204` | 204 | No body |
| `success_list_200` | 200 | `<<recordListType>>` with `<<recordListExample>>` |
| `success_list_201` | 201 | `<<recordListType>>` with `<<recordListExample>>` |
| `success_list_paged_200` | 200 | `<<recordListPagedType>>` with `<<recordListPagedExample>>` |
| `success_list_paged_201` | 201 | `<<recordListPagedType>>` with `<<recordListPagedExample>>` |

---

### 4. health-check (v1.0.2)

**Asset ID:** `health-check`
**Type:** `raml-fragment` (Library)
**Main file:** `health-check.raml`

Defines `healthCheckResponse` type:
```yaml
properties:
  timestamp: string (required)
  status: string (enum: Running, Down, Partial)
  details: object (optional)
```

Also provides a `check` resource type for GET `/health`.

---

### 5. roche_api-traits (v1.0.0)

**Asset ID:** `roche_api-traits`
**Type:** `raml-fragment` (Library)
**Main file:** `roche-api_traits.raml`

Defines the `paginated` trait with query parameters:
- `offset` — integer, default 0, minimum 0
- `limit` — integer, default 100, maximum `<<maxItems>>`

Usage: `is: [ paginated: { maxItems: 500 } ]`

---

### 6. standard-errors-library (v1.0.0)

**Asset ID:** `standard-errors-library`
**Type:** `raml-fragment` (Library)
**Main file:** `standard-errors-library.raml`

Legacy/alternative error library. Defines a simpler `Error` type:
```yaml
properties:
  message: string (required)
  details: string (optional)
```

And an `errorHandler` trait covering 400, 404, 405, 406, 408, 415, 500.

**Note:** The `roche-faultmessages` fragment is the preferred error library used by the resource types. Use `standard-errors-library` only if explicitly required.

---

## Exchange Download URL Pattern

```
https://anypoint.mulesoft.com/exchange/api/v2/assets/{ORG_ID}/{ASSET_ID}
```

The response JSON contains a `files` array. Look for `classifier: "fat-raml-fragment"` and use its `externalLink` to download the zip.

## Dependencies Between Fragments

```
roche-resourcetypes
  ├── uses: roche-responsemessages (success traits)
  ├── uses: roche-faultmessages (error traits)
  └── uses: health-check (healthcheck resource type references)

roche-faultmessages
  └── standalone (defines fault data types + traits)

roche-responsemessages
  └── standalone (defines success response traits)

health-check
  └── standalone (defines healthCheckResponse type)

roche_api-traits
  └── standalone (defines pagination trait)

standard-errors-library
  └── standalone (legacy error library)
```

## How a RAML API Spec Uses These Fragments

```yaml
#%RAML 1.0
title: My API
version: v1
baseUri: https://api.roche.com/my-api/{version}
mediaType: application/json

uses:
  resourceTypes: exchange_modules/7f34e134-ef86-4a88-a34a-368f44ff5920/roche-resourcetypes/1.0.17/roche-resourcetypes.raml
  faultMessages: exchange_modules/7f34e134-ef86-4a88-a34a-368f44ff5920/roche-faultmessages/1.0.5/roche-faultmessages.raml
  responseMessages: exchange_modules/7f34e134-ef86-4a88-a34a-368f44ff5920/roche-responsemessages/1.0.5/roche-responsemessages.raml
  healthCheck: exchange_modules/7f34e134-ef86-4a88-a34a-368f44ff5920/health-check/1.0.2/health-check.raml
  apiTraits: exchange_modules/7f34e134-ef86-4a88-a34a-368f44ff5920/roche_api-traits/1.0.0/roche-api_traits.raml
```
