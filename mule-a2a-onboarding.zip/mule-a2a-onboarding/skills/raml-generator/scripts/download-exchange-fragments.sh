#!/usr/bin/env bash
# Downloads Roche RAML fragments from Anypoint Exchange into exchange_modules/.
# Usage: ./download-exchange-fragments.sh <bearer_token> [output_dir]
#
# Requires: curl, unzip, python3

set -euo pipefail

TOKEN="${1:?Usage: $0 <bearer_token> [output_dir]}"
OUTPUT_DIR="${2:-.}"
ORG="7f34e134-ef86-4a88-a34a-368f44ff5920"
EXCHANGE_API="https://anypoint.mulesoft.com/exchange/api/v2/assets"

# Fragment definitions: asset_id
FRAGMENTS=(
  "roche-resourcetypes"
  "roche-faultmessages"
  "roche-responsemessages"
  "health-check"
  "roche_api-traits"
)

EXCHANGE_MODULES_DIR="$OUTPUT_DIR/exchange_modules/$ORG"
mkdir -p "$EXCHANGE_MODULES_DIR"

for ASSET in "${FRAGMENTS[@]}"; do
  echo "Fetching metadata for $ASSET..."

  # Get asset metadata to find version and download URL
  METADATA=$(curl -sf -H "Authorization: Bearer $TOKEN" "$EXCHANGE_API/$ORG/$ASSET")

  VERSION=$(echo "$METADATA" | python3 -c "import json,sys; print(json.load(sys.stdin)['version'])")
  DOWNLOAD_URL=$(echo "$METADATA" | python3 -c "
import json, sys
data = json.load(sys.stdin)
for f in data.get('files', []):
    if f.get('classifier') in ('fat-raml-fragment', 'raml-fragment'):
        print(f.get('externalLink', f.get('downloadURL', '')))
        break
")

  if [ -z "$DOWNLOAD_URL" ]; then
    echo "  WARNING: No download URL found for $ASSET, skipping."
    continue
  fi

  DEST_DIR="$EXCHANGE_MODULES_DIR/$ASSET/$VERSION"
  mkdir -p "$DEST_DIR"

  TMPZIP=$(mktemp /tmp/raml-fragment-XXXXXX.zip)
  echo "  Downloading $ASSET v$VERSION..."
  curl -sfL -o "$TMPZIP" "$DOWNLOAD_URL"

  echo "  Extracting to $DEST_DIR..."
  unzip -qo "$TMPZIP" -d "$DEST_DIR"
  rm -f "$TMPZIP"

  echo "  Done: $ASSET v$VERSION"
done

echo ""
echo "All fragments downloaded to $EXCHANGE_MODULES_DIR"
