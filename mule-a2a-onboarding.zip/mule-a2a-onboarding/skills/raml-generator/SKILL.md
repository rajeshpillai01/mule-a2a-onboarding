---
name: roche-raml-generator
agent: developer
description: >
  Generate RAML 1.0 API specifications using Roche's standard fragments from Anypoint Exchange.
  Downloads roche-resourcetypes, roche-faultmessages, roche-responsemessages, health-check,
  and roche_api-traits fragments, then scaffolds a complete API spec with /health endpoint,
  data types, examples, and exchange.json. Accepts a CSV mapping specification file to extract
  source fields and generate RAML data types and examples automatically.
  Use when asked to "generate RAML", "create API spec", "scaffold RAML for Roche",
  "new Roche API", "create RAML using Roche template", or "generate RAML from mapping".
---

# Roche RAML Generator

Generate RAML 1.0 API specifications that conform to Roche's Anypoint Platform standards by using the official RAML fragments published on Anypoint Exchange.

## Prerequisites

- Anypoint Platform bearer token (UUID format, e.g., `29a5d6fa-...`). Ask if not provided.
- A CSV mapping specification file with source field definitions. Ask for the file path or have the user paste/upload it.

## Workflow

### 1. Gather API requirements

Ask the user for:
- **Mapping specification CSV** — file path or pasted content. This is the primary input.
- **API name** (kebab-case, e.g., `order-management-api`)
- **API title** (human-readable)
- **API version** (default: `v1`)
- **Base URI host** (default: `api.roche.com`)
- **Description** (one sentence)
- **Resources** — endpoints the API needs (e.g., `/orders`, `/orders/{orderId}`)
- **For each resource**: sync vs async, paginated or not

If the user provides only the CSV and endpoint paths, infer the rest from the CSV content.

### 2. Parse the mapping specification CSV

Read `references/csv-mapping-spec.md` for the full CSV parsing rules. Summary:

1. Read the CSV file. Detect columns by name (case-insensitive): Field Name, Data Type, Description, Required, Length, Example, Enum Values, Segment/Group.
2. Extract the **source fields** — these become RAML data type properties.
3. Map CSV data types to RAML types (String→string, Integer→integer, Decimal→number, Boolean→boolean, Date→date-only, DateTime→datetime).
4. If the CSV has a Segment/Group column, group fields by segment. Each segment becomes a separate RAML data type. Nested or repeatable segments become nested objects or arrays in the parent type.
5. If no segments, treat all fields as properties of a single data type named after the API resource.

### 3. Download Exchange fragments

Run the download script:

```bash
./scripts/download-exchange-fragments.sh "<bearer_token>" "<project_dir>"
```

Read the downloaded fragment directories to get exact version numbers for `uses:` declarations.

### 4. Create the project structure

```
<api-name>/
├── <api-name>.raml          # Main API spec
├── exchange.json             # Exchange metadata with fragment dependencies
├── examples/                 # JSON examples (generated from CSV)
│   ├── health-check-response.json
│   ├── <type-name>.json          # Single-record example per type
│   └── <type-name>-list.json     # Collection example per type
├── data-types/               # RAML DataType fragments (generated from CSV)
│   └── <TypeName>.raml           # One per segment/group
└── exchange_modules/         # Downloaded Roche fragments
```

### 5. Generate data types from CSV fields

For each segment/group extracted in step 2, create a RAML DataType fragment:

```yaml
#%RAML 1.0 DataType
type: object
description: <derived from segment name or resource>
properties:
  fieldName:
    type: string
    description: <from CSV Description column>
    required: true
    maxLength: 15
    example: "ABC123"
```

Rules:
- Use the CSV Field Name as the RAML property name (camelCase if it contains spaces).
- Set `type` from the CSV Data Type column using the mapping in `references/csv-mapping-spec.md`.
- Set `maxLength` from the CSV Length column (for string types only).
- Set `required` from the CSV Required column (default: true).
- Set `example` from the CSV Example column. If missing, generate a plausible value.
- Set `enum` from the CSV Enum Values column (pipe-separated).

### 6. Generate JSON examples from CSV fields

For each data type:
1. Create `examples/<type-name>.json` — a single object with values from the CSV Example column (or generated).
2. Create `examples/<type-name>-list.json` — an array of 2 objects with varied example values.
3. Copy `assets/examples/health-check-response.json` to `examples/`.

### 7. Generate the RAML spec

Use `assets/api-template.raml` as the starting point. Replace all `{{placeholders}}`.

#### Choosing resource types

Read `references/roche-fragments-catalog.md` for the full guide. Summary:

| Pattern | Resource Type |
|---|---|
| Single record, sync | `resourceTypes.record-sync` |
| Single record, async (202) | `resourceTypes.record-async` |
| Collection, sync | `resourceTypes.collection-sync` |
| Paginated collection, sync | `resourceTypes.collection-paged-sync` |
| Health check | `resourceTypes.healthcheck` |

For paginated endpoints, also apply: `is: [ apiTraits.paginated: { maxItems: 500 } ]`

#### Wiring data types to resource types

The resource type parameters `recordType`, `recordExample`, `recordListType`, `recordListExample` must reference the RAML DataType fragments and JSON examples generated from the CSV:

```yaml
/resources:
  type:
    resourceTypes.collection-paged-sync:
      recordType: MyType
      recordExample: !include examples/my-type.json
      recordListPagedType: MyType[]
      recordListPagedExample: !include examples/my-type-list.json
      # ... other required parameters
```

### 8. Generate exchange.json

Use `assets/exchange.json.template`. Set dependency versions from what was downloaded.

### 9. Verify completeness

Check that:
- Every `!include` path resolves to an existing file
- No unfilled `<<placeholder>>` or `{{template}}` variables remain
- `exchange.json` lists all 5 fragment dependencies with correct versions
- `/health` endpoint is present
- Every data type generated from the CSV exists in `data-types/`
- Every example referenced exists in `examples/`
- Every field from the CSV source columns is represented in the RAML data types

## Anti-patterns

- Do NOT hardcode fragment versions — read them from downloaded fragments
- Do NOT use `standard-errors-library` — use `roche-faultmessages`
- Do NOT omit the `/health` endpoint — mandatory for all Roche APIs
- Do NOT define error responses manually — resource types wire them automatically
- Do NOT use RAML 0.8 syntax — always `#%RAML 1.0`
- Do NOT invent fields — only use fields present in the CSV source columns
- Do NOT skip CSV fields — every source field must appear in the generated data types
