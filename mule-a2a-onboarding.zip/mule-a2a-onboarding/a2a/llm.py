"""AsyncAnthropic client factory — handles auth, gateway URL, custom headers."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from typing import AsyncGenerator, Optional

from anthropic import AsyncAnthropic

DEFAULT_MODEL = "claude-sonnet-4-6[1m]"
_client: Optional[AsyncAnthropic] = None


def _resolve_token() -> str:
    token = os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN", "").strip()
    if token:
        return token
    build_cli = shutil.which("build-cli") or os.path.expanduser("~/.local/bin/build-cli")
    try:
        token = subprocess.check_output(
            [build_cli, "auth", "token"], text=True, stderr=subprocess.DEVNULL, timeout=15
        ).strip()
        if token:
            return token
    except Exception:
        pass
    raise RuntimeError(
        "No Anthropic API key found. Set ANTHROPIC_API_KEY, ANTHROPIC_AUTH_TOKEN, "
        "or authenticate via the Claude CLI."
    )


def _resolve_base_url() -> str:
    if url := os.environ.get("ANTHROPIC_BASE_URL"):
        return url
    settings = os.path.expanduser("~/.claude/settings.json")
    if os.path.exists(settings):
        try:
            with open(settings) as f:
                return json.load(f).get("env", {}).get("ANTHROPIC_BASE_URL", "https://api.anthropic.com")
        except Exception:
            pass
    return "https://api.anthropic.com"


def _resolve_headers() -> dict:
    raw = os.environ.get("ANTHROPIC_CUSTOM_HEADERS", "x-build-cli-tool: claude")
    headers = {}
    for part in raw.split(","):
        part = part.strip()
        if ":" in part:
            k, v = part.split(":", 1)
            headers[k.strip()] = v.strip()
    return headers


def get_llm_client() -> AsyncAnthropic:
    global _client
    if _client is None:
        token    = _resolve_token()
        base_url = _resolve_base_url()
        headers  = _resolve_headers()
        os.environ["ANTHROPIC_API_KEY"]  = token
        os.environ["ANTHROPIC_BASE_URL"] = base_url
        _client = AsyncAnthropic(
            api_key=token,
            base_url=base_url,
            default_headers=headers,
        )
    return _client


async def stream_llm(
    system: str,
    user: str,
    model: str = DEFAULT_MODEL,
    max_tokens: int = 16384,
) -> AsyncGenerator[str, None]:
    """Yield text chunks from a streaming Claude call."""
    client = get_llm_client()
    async with client.messages.stream(
        model=model,
        max_tokens=max_tokens,
        system=system,
        messages=[{"role": "user", "content": user}],
    ) as stream:
        async for text in stream.text_stream:
            yield text


async def complete_llm(
    system: str,
    user: str,
    model: str = DEFAULT_MODEL,
    max_tokens: int = 2048,
) -> str:
    """Return full response text from a non-streaming Claude call."""
    client = get_llm_client()
    response = await client.messages.create(
        model=model,
        max_tokens=max_tokens,
        system=system,
        messages=[{"role": "user", "content": user}],
    )
    return response.content[0].text if response.content else ""
