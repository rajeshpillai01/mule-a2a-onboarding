"""Async A2A HTTP client — send tasks and subscribe to SSE streams."""
from __future__ import annotations

import json
import uuid
from typing import Any, AsyncGenerator, Optional

import httpx

from .models import AgentCard, Message, SendTaskRequest, Task, TextPart, DataPart


class A2AClient:
    def __init__(self, timeout: float = 600.0):
        self.timeout = timeout

    async def get_agent_card(self, base_url: str) -> AgentCard:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.get(f"{base_url}/.well-known/agent.json")
            r.raise_for_status()
            return AgentCard(**r.json())

    async def send_task(
        self,
        base_url: str,
        message: Message,
        task_id: Optional[str] = None,
        skill_id: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> Task:
        """Non-streaming task — blocks until agent returns completed/failed."""
        req = SendTaskRequest(
            id=task_id or str(uuid.uuid4()),
            message=message,
            skillId=skill_id,
            metadata=metadata,
        )
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            r = await c.post(
                f"{base_url}/tasks/send",
                json=req.model_dump(),
            )
            r.raise_for_status()
            return Task(**r.json())

    async def send_subscribe(
        self,
        base_url: str,
        message: Message,
        task_id: Optional[str] = None,
        skill_id: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> AsyncGenerator[dict, None]:
        """SSE streaming task — yields parsed event dicts."""
        req = SendTaskRequest(
            id=task_id or str(uuid.uuid4()),
            message=message,
            skillId=skill_id,
            metadata=metadata,
        )
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            async with c.stream(
                "POST",
                f"{base_url}/tasks/sendSubscribe",
                json=req.model_dump(),
                headers={"Accept": "text/event-stream"},
            ) as response:
                response.raise_for_status()
                buffer = ""
                async for chunk in response.aiter_text():
                    buffer += chunk
                    while "\n\n" in buffer:
                        event_str, buffer = buffer.split("\n\n", 1)
                        for line in event_str.splitlines():
                            if line.startswith("data:"):
                                raw = line[5:].strip()
                                if raw and raw != "[DONE]":
                                    try:
                                        yield json.loads(raw)
                                    except json.JSONDecodeError:
                                        pass

    # ── Message factories ────────────────────────────────────────────────────

    @staticmethod
    def text_message(text: str, role: str = "user") -> Message:
        return Message(role=role, parts=[TextPart(text=text)])

    @staticmethod
    def data_message(data: Any, role: str = "user") -> Message:
        return Message(role=role, parts=[DataPart(data=data)])

    @staticmethod
    def mixed_message(text: str, data: Any, role: str = "user") -> Message:
        return Message(role=role, parts=[TextPart(text=text), DataPart(data=data)])
