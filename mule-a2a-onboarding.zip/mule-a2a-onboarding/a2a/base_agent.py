"""Base FastAPI A2A agent — registers all standard A2A routes."""
from __future__ import annotations

import json
from typing import AsyncGenerator, Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse

from .models import (
    AgentCard, Artifact, DataPart, Message, SendTaskRequest,
    Task, TaskState, TaskStatus, TextPart,
    status_event, chunk_event, artifact_event,
    input_required_event, completed_event, error_event,
)


class BaseA2AAgent:
    """
    Subclass and override handle_send() and/or handle_stream().
    self.app is the FastAPI instance to pass to uvicorn.
    """

    def __init__(self, card: AgentCard):
        self.card  = card
        self.tasks: dict[str, Task] = {}
        self.app   = FastAPI(title=card.name, version=card.version)
        self._register_routes()

    def _register_routes(self):
        agent = self  # capture for closures

        @self.app.get("/.well-known/agent.json")
        async def agent_card():
            return agent.card.model_dump()

        @self.app.post("/tasks/send")
        async def send_task(req: SendTaskRequest):
            task = agent._get_or_create_task(req)
            task.history.append(req.message)
            task.status = TaskStatus(state=TaskState.WORKING)
            try:
                result = await agent.handle_send(req, task)
                agent.tasks[req.id] = result
                return result.model_dump()
            except NotImplementedError:
                raise HTTPException(status_code=501, detail="handle_send not implemented")
            except Exception as e:
                task.status = TaskStatus(state=TaskState.FAILED, message=str(e))
                agent.tasks[req.id] = task
                raise HTTPException(status_code=500, detail=str(e))

        @self.app.post("/tasks/sendSubscribe")
        async def send_subscribe(req: SendTaskRequest):
            task = agent._get_or_create_task(req)
            task.history.append(req.message)
            task.status = TaskStatus(state=TaskState.WORKING)

            async def event_stream():
                try:
                    async for ev in agent.handle_stream(req, task):
                        yield f"data: {json.dumps(ev)}\n\n"
                except Exception as e:
                    yield f"data: {json.dumps(error_event(str(e)))}\n\n"
                finally:
                    yield "data: [DONE]\n\n"

            return StreamingResponse(
                event_stream(),
                media_type="text/event-stream",
                headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
            )

        @self.app.get("/tasks/{task_id}")
        async def get_task(task_id: str):
            if task_id not in agent.tasks:
                raise HTTPException(status_code=404, detail="Task not found")
            return agent.tasks[task_id].model_dump()

        @self.app.get("/health")
        async def health():
            return {"status": "ok", "agent": agent.card.name}

    def _get_or_create_task(self, req: SendTaskRequest) -> Task:
        if req.id not in self.tasks:
            self.tasks[req.id] = Task(
                id=req.id,
                status=TaskStatus(state=TaskState.SUBMITTED),
            )
        return self.tasks[req.id]

    async def handle_send(self, req: SendTaskRequest, task: Task) -> Task:
        raise NotImplementedError

    async def handle_stream(
        self, req: SendTaskRequest, task: Task
    ) -> AsyncGenerator[dict, None]:
        raise NotImplementedError
        yield  # make it a generator

    # ── Helpers ──────────────────────────────────────────────────────────────

    @staticmethod
    def make_completed_task(task: Task, text: str) -> Task:
        task.status = TaskStatus(state=TaskState.COMPLETED)
        task.artifacts = [Artifact(parts=[TextPart(text=text)])]
        return task

    @staticmethod
    def make_completed_task_data(task: Task, data: dict) -> Task:
        task.status = TaskStatus(state=TaskState.COMPLETED)
        task.artifacts = [Artifact(parts=[DataPart(data=data)])]
        return task

    @staticmethod
    def make_input_required_task(task: Task, questions: list) -> Task:
        task.status = TaskStatus(state=TaskState.INPUT_REQUIRED)
        task.artifacts = [Artifact(parts=[DataPart(data={"questions": questions})])]
        return task
