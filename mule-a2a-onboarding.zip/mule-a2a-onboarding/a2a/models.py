"""A2A protocol data models (Google Agent-to-Agent spec)."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, List, Literal, Optional, Union

from pydantic import BaseModel, Field


# ── Task lifecycle ───────────────────────────────────────────────────────────

class TaskState(str, Enum):
    SUBMITTED       = "submitted"
    WORKING         = "working"
    INPUT_REQUIRED  = "input-required"
    COMPLETED       = "completed"
    FAILED          = "failed"
    CANCELED        = "canceled"


# ── Message parts ────────────────────────────────────────────────────────────

class TextPart(BaseModel):
    type: Literal["text"] = "text"
    text: str


class DataPart(BaseModel):
    type: Literal["data"] = "data"
    data: Any


class FilePart(BaseModel):
    type: Literal["file"] = "file"
    name: str
    mimeType: str = "application/octet-stream"
    bytes: Optional[str] = None   # base64-encoded
    uri: Optional[str] = None


Part = Union[TextPart, DataPart, FilePart]


# ── Message / Artifact ───────────────────────────────────────────────────────

class Message(BaseModel):
    role: str                     # "user" | "agent"
    parts: List[Part]

    def text(self) -> str:
        """Return the concatenated text of all TextParts."""
        return " ".join(p.text for p in self.parts if isinstance(p, TextPart))

    def data(self) -> Optional[Any]:
        """Return the data from the first DataPart, if any."""
        for p in self.parts:
            if isinstance(p, DataPart):
                return p.data
        return None


class Artifact(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    parts: List[Part]
    index: int = 0
    append: bool = False
    lastChunk: bool = False


# ── Task ─────────────────────────────────────────────────────────────────────

class TaskStatus(BaseModel):
    state: TaskState
    message: Optional[str] = None
    timestamp: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


class Task(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    status: TaskStatus = Field(
        default_factory=lambda: TaskStatus(state=TaskState.SUBMITTED)
    )
    history: List[Message] = Field(default_factory=list)
    artifacts: List[Artifact] = Field(default_factory=list)
    metadata: Optional[dict] = None


# ── Request / Response ───────────────────────────────────────────────────────

class SendTaskRequest(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    message: Message
    skillId: Optional[str] = None
    sessionId: Optional[str] = None
    metadata: Optional[dict] = None


# ── Agent Card ───────────────────────────────────────────────────────────────

class AgentCapabilities(BaseModel):
    streaming: bool = True
    pushNotifications: bool = False
    stateTransitionHistory: bool = True


class AgentSkill(BaseModel):
    id: str
    name: str
    description: str
    inputModes: List[str] = ["text"]
    outputModes: List[str] = ["text"]
    tags: List[str] = []


class AgentCard(BaseModel):
    name: str
    description: str
    url: str
    version: str = "1.0.0"
    capabilities: AgentCapabilities = Field(default_factory=AgentCapabilities)
    skills: List[AgentSkill]
    defaultInputMode: str = "text"
    defaultOutputMode: str = "text"


# ── SSE event helpers ─────────────────────────────────────────────────────────

def status_event(state: str) -> dict:
    return {"type": "status", "state": state,
            "timestamp": datetime.now(timezone.utc).isoformat()}

def chunk_event(text: str) -> dict:
    return {"type": "chunk", "text": text}

def artifact_event(data: Any, name: str = "output") -> dict:
    return {"type": "artifact", "name": name, "data": data}

def text_artifact_event(text: str, name: str = "output") -> dict:
    return {"type": "artifact", "name": name, "text": text}

def input_required_event(questions: list) -> dict:
    return {"type": "input_required", "questions": questions}

def completed_event(artifact: Optional[dict] = None) -> dict:
    ev: dict = {"type": "completed"}
    if artifact:
        ev["artifact"] = artifact
    return ev

def error_event(message: str) -> dict:
    return {"type": "error", "message": message}

def pipeline_event(event_type: str, agent: str, content: str, target: str = "") -> dict:
    ev = {"type": "pipeline_event", "event_type": event_type,
          "agent": agent, "content": content}
    if target:
        ev["target"] = target
    return ev

def file_creating_event(path: str) -> dict:
    return {"type": "file_creating", "path": path}

def file_created_event(path: str, size: int) -> dict:
    return {"type": "file_created", "path": path, "size": size}
