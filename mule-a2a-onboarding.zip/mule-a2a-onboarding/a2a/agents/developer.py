"""Developer Agent — generates AGENTS.md instructions from TDS."""
from __future__ import annotations

import json
import os
import re
import time

import httpx
from fastapi import FastAPI

from ..base_agent import BaseA2AAgent
from ..llm import stream_llm, complete_llm
from ..models import (
    AgentCard, AgentSkill, SendTaskRequest, Task, TaskState, TaskStatus,
    DataPart, TextPart, Artifact,
    status_event, chunk_event, artifact_event, completed_event,
    input_required_event,
)
from schemas.pipeline import OnaInstructionSet

PORT = 8103
REGISTRY_URL = "http://localhost:8105"
WORKSPACE_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
AGENTS_MD_PATH = os.path.join(WORKSPACE_ROOT, "AGENTS.md")
SKILLS_DIR     = os.path.join(WORKSPACE_ROOT, "skills")

CARD = AgentCard(
    name="Developer Agent",
    description="Integration Developer — synthesises TDS into precise RAML, Mule 4 XML, and MUnit coding instructions for the Ona code-generation agent.",
    url=f"http://localhost:{PORT}",
    skills=[
        AgentSkill(
            id="generate-agents-md",
            name="Generate AGENTS.md",
            description="Convert a Technical Design Spec into developer and tester marching orders for the Ona agent.",
            inputModes=["data"],
            outputModes=["data"],
            tags=["developer", "agents-md"],
        ),
    ],
)

_GATE_SYSTEM = (
    "You are a MuleSoft Integration Developer reviewing upstream technical design work before "
    "starting implementation. Identify only critical technical gaps that would block your "
    "implementation. Do NOT ask obvious or trivial questions."
)

_ONA_SCHEMA_JSON = json.dumps(OnaInstructionSet.model_json_schema(), indent=2)


def _discover_skill_names() -> list:
    if not os.path.isdir(SKILLS_DIR):
        return []
    names = []
    for name in sorted(os.listdir(SKILLS_DIR)):
        skill_dir = os.path.join(SKILLS_DIR, name)
        skill_md  = os.path.join(skill_dir, "SKILL.md")
        if os.path.isdir(skill_dir) and os.path.exists(skill_md):
            with open(skill_md) as f:
                content = f.read()
            if content.startswith("---"):
                end = content.find("---", 3)
                if end != -1:
                    for line in content[3:end].splitlines():
                        if line.strip().startswith("agent:") and "developer" in line:
                            names.append(name)
                            break
    return names


def _developer_system() -> str:
    skill_names = _discover_skill_names()
    skill_directive = ""
    if skill_names:
        skill_directive = (
            f"\n\nIMPORTANT — Developer Skills Available: {', '.join(skill_names)}. "
            f"For RAML API specification generation the developer MUST follow the "
            f"raml-generator skill located at skills/raml-generator/SKILL.md."
        )
    return (
        "You are an Integration Project Delivery Specialist. Write the sequential programming "
        "instructions and testing criteria that the Ona Agent needs to execute (Developer + Tester roles). "
        "Instruct Ona on how to create RAML schemas, generate Mule 4 XML flow code, and construct "
        "complete MUnit tests with mock data." + skill_directive + "\n\n"
        "CRITICAL: Output ONLY valid JSON adhering strictly to this JSON Schema:\n"
        + _ONA_SCHEMA_JSON
    )


def _clean_json(text: str) -> str:
    text = text.strip()
    for fence in ("```json", "```"):
        if text.startswith(fence):
            text = text[len(fence):]
    if text.endswith("```"):
        text = text[:-3]
    text = text.strip()
    if text.startswith("{"):
        return text
    start = text.find("{")
    if start != -1:
        depth = 0
        for i, ch in enumerate(text[start:], start):
            depth += 1 if ch == "{" else (-1 if ch == "}" else 0)
            if depth == 0:
                candidate = text[start: i + 1]
                try:
                    json.loads(candidate)
                    return candidate
                except Exception:
                    break
    return text


def _write_agents_md(spec: OnaInstructionSet):
    with open(AGENTS_MD_PATH, "w", encoding="utf-8") as f:
        f.write("# AUTOMATED AGENT LIFE CYCLE SPECIFICATION\n\n")
        f.write("This spec provides absolute guidelines for Ona's coding environment.\n\n")
        f.write("## Project Setup\n")
        f.write(f"- **Target Application Name:** {spec.target_project_name}\n")
        f.write("- **Target Folders:**\n" + "\n".join(f"  - `{d}`" for d in spec.project_directories) + "\n\n")
        f.write(f"## Core RAML Design Mandates\n{spec.raml_scaffolding_marching_orders}\n\n")
        f.write(f"## Role 3 (Developer): Mule 4 Code Generation Directives\n{spec.mule_xml_generation_marching_orders}\n\n")
        f.write(f"## Role 4 (Tester): MUnit Testing Directives\n{spec.munit_testing_marching_orders}\n")


async def _check_clarifications(tds_preview: str) -> list:
    user = (
        f"Your upcoming task: Generate RAML schemas, Mule 4 XML flows, and MUnit tests.\n\n"
        f"Upstream TDS (first 6000 chars):\n{tds_preview[:6000]}\n\n"
        f"You may consult the Developer Lead Agent or the Architect Agent. "
        f"Identify up to 2 specific technical questions that would block implementation.\n\n"
        f"Respond ONLY as:\n"
        f"CONSULT: <dev_lead|architect> | <specific question>\n\n"
        f"Or:\nNO_CLARIFICATION_NEEDED"
    )
    response = await complete_llm(_GATE_SYSTEM, user, max_tokens=512)
    if "NO_CLARIFICATION_NEEDED" in response or not response.strip():
        return []
    questions = []
    for line in response.splitlines():
        m = re.match(r"CONSULT:\s*(\w+)\s*\|\s*(.+)", line.strip())
        if m:
            target   = m.group(1).strip().lower()
            question = m.group(2).strip()
            if target in ("dev_lead", "architect") and question:
                questions.append({"target": target, "question": question})
        if len(questions) >= 2:
            break
    return questions


class DeveloperAgent(BaseA2AAgent):
    def __init__(self):
        super().__init__(CARD)
        self._self_register()

    def _self_register(self):
        @self.app.on_event("startup")
        async def _register():
            for _ in range(5):
                try:
                    async with httpx.AsyncClient(timeout=3) as c:
                        await c.post(f"{REGISTRY_URL}/register",
                                     json={"card": CARD.model_dump()})
                    return
                except Exception:
                    time.sleep(1)

    async def handle_stream(self, req: SendTaskRequest, task: Task):
        yield status_event("working")

        payload = req.message.data() or {}
        tds_json = payload.get("tds_json", "") or payload.get("tds", "")
        if isinstance(tds_json, dict):
            tds_json = json.dumps(tds_json)
        clarification_answers = payload.get("clarification_answers", [])

        # Clarification gate
        if len(task.history) == 1 and not clarification_answers:
            questions = await _check_clarifications(tds_json)
            if questions:
                task.status = TaskStatus(state=TaskState.INPUT_REQUIRED)
                self.tasks[task.id] = task
                yield input_required_event(questions)
                return

        extra = ""
        if clarification_answers:
            extra = "\n\nClarifications obtained:\n" + "\n\n".join(
                f"Q: {qa['question']}\nA: {qa['answer']}" for qa in clarification_answers
            )

        system = _developer_system()
        user   = f"Synthesise this TDS into developer and tester marching orders:\n\n{tds_json}{extra}"

        full_text = ""
        async for chunk in stream_llm(system, user):
            yield chunk_event(chunk)
            full_text += chunk

        ona_json_str = _clean_json(full_text)
        try:
            spec     = OnaInstructionSet.model_validate_json(ona_json_str)
            ona_dict = spec.model_dump()
            _write_agents_md(spec)
        except Exception:
            ona_dict = json.loads(ona_json_str) if ona_json_str else {}

        task.status = TaskStatus(state=TaskState.COMPLETED)
        task.artifacts = [Artifact(parts=[DataPart(data=ona_dict)])]
        self.tasks[task.id] = task

        yield artifact_event(ona_dict, name="agents_md")
        yield completed_event({"agents_md": ona_dict})


_agent_instance = DeveloperAgent()
app: FastAPI = _agent_instance.app
