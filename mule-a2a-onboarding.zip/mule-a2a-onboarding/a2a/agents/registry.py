"""Agent Registry — discovery service for all A2A agents."""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI(title="A2A Agent Registry", version="1.0.0")

_agents: dict[str, dict] = {}


class RegisterRequest(BaseModel):
    card: dict


@app.post("/register")
async def register(req: RegisterRequest):
    name = req.card.get("name")
    if not name:
        raise HTTPException(status_code=400, detail="Agent card must have a name")
    _agents[name] = req.card
    return {"registered": name}


@app.get("/agents")
async def list_agents():
    return list(_agents.values())


@app.get("/agents/{name}")
async def get_agent(name: str):
    if name not in _agents:
        raise HTTPException(status_code=404, detail=f"Agent '{name}' not found")
    return _agents[name]


@app.get("/health")
async def health():
    return {"status": "ok", "registered": list(_agents.keys())}
