"""Ona Agent — reads AGENTS.md and generates a complete Mule 4 project."""
from __future__ import annotations

import json
import os
import subprocess
import time

import httpx
from fastapi import FastAPI

from ..base_agent import BaseA2AAgent
from ..llm import stream_llm
from ..models import (
    AgentCard, AgentSkill, SendTaskRequest, Task, TaskState, TaskStatus,
    DataPart, Artifact,
    status_event, chunk_event, completed_event, error_event,
    file_creating_event, file_created_event,
)

PORT = 8104
REGISTRY_URL   = "http://localhost:8105"
WORKSPACE_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SKILLS_DIR     = os.path.join(WORKSPACE_ROOT, "skills")
MULE_DIR       = os.path.join(WORKSPACE_ROOT, "mule-project")

CARD = AgentCard(
    name="Ona Agent",
    description="MuleSoft Integration Developer (Ona) — reads AGENTS.md instructions and generates a complete Mule 4 project with RAML specs, XML flows, DataWeave transforms, and MUnit tests.",
    url=f"http://localhost:{PORT}",
    skills=[
        AgentSkill(
            id="generate-mule-project",
            name="Generate Mule 4 Project",
            description="Stream-generate every file of a Mule 4 project from AGENTS.md instructions.",
            inputModes=["data"],
            outputModes=["file"],
            tags=["mule4", "raml", "dataweave", "munit"],
        ),
    ],
)


def _load_skill(skill_name: str) -> dict:
    skill_dir = os.path.join(SKILLS_DIR, skill_name)
    result: dict = {"name": skill_name, "assets": {}, "references": {}}
    skill_md = os.path.join(skill_dir, "SKILL.md")
    if os.path.exists(skill_md):
        with open(skill_md, encoding="utf-8") as f:
            result["instructions"] = f.read()
    assets_dir = os.path.join(skill_dir, "assets")
    if os.path.isdir(assets_dir):
        for root, _, files in os.walk(assets_dir):
            for fname in files:
                fpath = os.path.join(root, fname)
                rel   = os.path.relpath(fpath, assets_dir)
                try:
                    with open(fpath, encoding="utf-8") as f:
                        result["assets"][rel] = f.read()
                except Exception:
                    pass
    refs_dir = os.path.join(skill_dir, "references")
    if os.path.isdir(refs_dir):
        for fname in os.listdir(refs_dir):
            fpath = os.path.join(refs_dir, fname)
            if os.path.isfile(fpath):
                try:
                    with open(fpath, encoding="utf-8") as f:
                        result["references"][fname] = f.read()
                except Exception:
                    pass
    scripts_dir = os.path.join(skill_dir, "scripts")
    if os.path.isdir(scripts_dir):
        result["scripts_dir"] = scripts_dir
    return result


def _discover_developer_skills() -> list:
    if not os.path.isdir(SKILLS_DIR):
        return []
    matched = []
    for skill_name in sorted(os.listdir(SKILLS_DIR)):
        skill_dir = os.path.join(SKILLS_DIR, skill_name)
        skill_md  = os.path.join(skill_dir, "SKILL.md")
        if not os.path.isdir(skill_dir) or not os.path.exists(skill_md):
            continue
        with open(skill_md, encoding="utf-8") as f:
            content = f.read()
        if content.startswith("---"):
            end = content.find("---", 3)
            if end != -1:
                for line in content[3:end].splitlines():
                    if line.strip().startswith("agent:") and "developer" in line:
                        matched.append(_load_skill(skill_name))
                        break
    return matched


def _build_skill_context(skills: list, project_dir: str, anypoint_token: str) -> str:
    blocks = []
    for skill in skills:
        block = f"\n\n{'='*60}\nSKILL: {skill['name']}\n{'='*60}\n"
        if skill.get("instructions"):
            block += f"\n### Skill Instructions\n{skill['instructions']}\n"
        for ref_name, ref_content in skill.get("references", {}).items():
            block += f"\n### Reference: {ref_name}\n{ref_content}\n"
        raml_template = skill.get("assets", {}).get("api-template.raml", "")
        if raml_template:
            block += f"\n### RAML Template\n```raml\n{raml_template}\n```\n"
        if anypoint_token:
            block += (
                f"\nNote: Roche RAML fragments downloaded to "
                f"`{os.path.join(project_dir, 'exchange_modules')}/`. "
                f"Read the downloaded directories for exact version numbers.\n"
            )
        else:
            block += "\nNote: No Anypoint token — use hardcoded fragment versions from the catalog reference.\n"
        blocks.append(block)
    return "".join(blocks)


class OnaAgent(BaseA2AAgent):
    def __init__(self):
        super().__init__(CARD)
        self._self_register()

    def _self_register(self):
        @self.app.on_event("startup")
        async def _register():
            for _ in range(5):
                try:
                    async with httpx.AsyncClient(timeout=3) as c:
                        await c.post(f"{REGISTRY_URL}/register",
                                     json={"card": CARD.model_dump()})
                    return
                except Exception:
                    time.sleep(1)

    async def handle_stream(self, req: SendTaskRequest, task: Task):
        yield status_event("working")

        payload       = req.message.data() or {}
        agents_md     = payload.get("agents_md", "")
        csv_content   = payload.get("csv_content", "")
        anypoint_token = payload.get("anypoint_token", "")
        project_dir   = payload.get("project_dir", MULE_DIR)

        os.makedirs(project_dir, exist_ok=True)

        # Discover and prepare skills
        dev_skills = _discover_developer_skills()
        for skill in dev_skills:
            scripts_dir    = skill.get("scripts_dir")
            download_script = os.path.join(scripts_dir, "download-exchange-fragments.sh") if scripts_dir else None
            if download_script and os.path.exists(download_script) and anypoint_token:
                try:
                    result = subprocess.run(
                        ["bash", download_script, anypoint_token, project_dir],
                        capture_output=True, text=True, timeout=120,
                    )
                    if result.returncode != 0:
                        yield {"type": "skill_prep_skip",
                               "content": f"Fragment download failed — continuing without pre-downloaded fragments"}
                    else:
                        yield {"type": "skill_prep_done",
                               "content": "RAML fragments downloaded to exchange_modules/"}
                except Exception as e:
                    yield {"type": "skill_prep_skip", "content": f"Fragment download error: {e}"}
            elif download_script and not anypoint_token:
                yield {"type": "skill_prep_skip",
                       "content": "No Anypoint token — skipping fragment download"}

        skill_context = _build_skill_context(dev_skills, project_dir, anypoint_token)
        csv_section   = ""
        if csv_content:
            csv_section = f"\n\n## CSV Mapping Specification\n\n```csv\n{csv_content}\n```\n"

        system = (
            "You are Ona, a MuleSoft Integration Developer executing developer instructions. "
            "Generate every required Mule 4 project file in full — never truncate or summarise. "
            "For EACH file use EXACTLY this format (no variation):\n\n"
            "===FILE: relative/path/to/file.ext===\n"
            "<complete file content>\n"
            "===END_FILE===\n\n"
            "Files to generate: RAML 1.0 API spec, DataType fragments, JSON examples, "
            "exchange.json, Mule 4 XML flows (globals, main flows, error handlers), "
            "MUnit 2.x test suites with mocks, pom.xml, mule-artifact.json."
            + skill_context
        )
        user = (
            "Execute the following developer and tester instructions. "
            "Generate EVERY file listed using the ===FILE:===...===END_FILE=== format."
            + csv_section
            + "\n\n## Developer & Tester Instructions (AGENTS.md)\n\n"
            + agents_md
        )

        # Stream + parse file blocks
        buffer       = ""
        current_path = None
        current_lines: list = []
        file_manifest: list = []
        char_count   = 0

        async for chunk in stream_llm(system, user, max_tokens=32768):
            char_count += len(chunk)
            yield chunk_event(str(char_count))
            buffer += chunk

            while "\n" in buffer:
                line, buffer = buffer.split("\n", 1)
                stripped = line.strip()

                if stripped.startswith("===FILE:") and stripped.endswith("===") and stripped != "===FILE:===":
                    inner = stripped[8: stripped.rfind("===")].strip().lstrip("/")
                    if inner and ".." not in inner:
                        current_path  = inner
                        current_lines = []
                        yield file_creating_event(current_path)

                elif stripped == "===END_FILE===" and current_path:
                    content   = "\n".join(current_lines)
                    full_path = os.path.join(project_dir, current_path)
                    os.makedirs(os.path.dirname(full_path), exist_ok=True)
                    with open(full_path, "w", encoding="utf-8") as fh:
                        fh.write(content)
                    file_manifest.append({"path": current_path, "size": len(content)})
                    yield file_created_event(current_path, len(content))
                    current_path  = None
                    current_lines = []

                elif current_path is not None:
                    current_lines.append(line)

        # Flush any trailing file without ===END_FILE===
        if current_path and current_lines:
            content   = "\n".join(current_lines)
            full_path = os.path.join(project_dir, current_path)
            os.makedirs(os.path.dirname(full_path), exist_ok=True)
            with open(full_path, "w", encoding="utf-8") as fh:
                fh.write(content)
            file_manifest.append({"path": current_path, "size": len(content)})
            yield file_created_event(current_path, len(content))

        task.status = TaskStatus(state=TaskState.COMPLETED)
        task.artifacts = [Artifact(parts=[DataPart(data={"files": file_manifest})])]
        self.tasks[task.id] = task

        yield completed_event({"files": file_manifest, "project_dir": project_dir})


_agent_instance = OnaAgent()
app: FastAPI = _agent_instance.app
