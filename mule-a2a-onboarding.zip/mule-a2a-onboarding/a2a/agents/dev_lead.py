"""Developer Lead Agent — generates TDS, supports clarification gate."""
from __future__ import annotations

import json
import re
import time

import httpx
from fastapi import FastAPI

from ..base_agent import BaseA2AAgent
from ..llm import stream_llm, complete_llm
from ..models import (
    AgentCard, AgentSkill, SendTaskRequest, Task, TaskState, TaskStatus,
    DataPart, TextPart, Artifact,
    status_event, chunk_event, artifact_event, completed_event,
    input_required_event, error_event,
)
from schemas.pipeline import TechnicalDesignSpec

PORT = 8102
REGISTRY_URL = "http://localhost:8105"

CARD = AgentCard(
    name="Developer Lead Agent",
    description="Roche Developer Lead — converts ISAG into a Technical Design Specification with endpoint definitions, security policies, and DataWeave transformation rules.",
    url=f"http://localhost:{PORT}",
    skills=[
        AgentSkill(
            id="generate-tds",
            name="Generate Technical Design Spec",
            description="Convert an ISAG into a full Technical Design Specification.",
            inputModes=["data"],
            outputModes=["data"],
            tags=["tds", "design"],
        ),
        AgentSkill(
            id="answer-clarification",
            name="Answer Clarification",
            description="Answer technical questions from the Developer about the TDS.",
            inputModes=["text"],
            outputModes=["text"],
            tags=["clarification"],
        ),
    ],
)

_GATE_SYSTEM = (
    "You are a Roche Developer Lead reviewing upstream architectural work before starting "
    "your own task. Identify only critical technical gaps that would genuinely affect your "
    "deliverable quality. Do NOT ask obvious or trivial questions."
)

_TDS_SCHEMA_JSON = json.dumps(TechnicalDesignSpec.model_json_schema(), indent=2)

def _tds_system() -> str:
    return (
        "You are a Roche Developer Lead. You receive an Integration Solution Architecture "
        "Guide (ISAG). Generate a comprehensive Technical Design Specification (TDS) with "
        "endpoint definitions, security policies, DataWeave mapping summary, and error handling.\n\n"
        "CRITICAL: Output ONLY valid JSON adhering strictly to this JSON Schema:\n"
        + _TDS_SCHEMA_JSON
    )


def _clean_json(text: str) -> str:
    text = text.strip()
    if text.startswith("```json"):
        text = text[7:]
    elif text.startswith("```"):
        text = text[3:]
    if text.endswith("```"):
        text = text[:-3]
    text = text.strip()
    if text.startswith("{"):
        return text
    start = text.find("{")
    if start != -1:
        depth = 0
        for i, ch in enumerate(text[start:], start):
            depth += 1 if ch == "{" else (-1 if ch == "}" else 0)
            if depth == 0:
                candidate = text[start: i + 1]
                try:
                    json.loads(candidate)
                    return candidate
                except Exception:
                    break
    return text


async def _check_clarifications(isag_preview: str) -> list:
    """Ask Dev Lead's Claude whether it needs clarification. Returns list of {target, question}."""
    user = (
        f"Your upcoming task: Generate a Technical Design Specification from the ISAG.\n\n"
        f"Upstream deliverable (first 6000 chars):\n{isag_preview[:6000]}\n\n"
        f"You may consult the Architect Agent. Identify up to 2 specific technical questions "
        f"whose answers would change how you design the TDS.\n\n"
        f"Respond ONLY as:\n"
        f"CONSULT: architect | <specific technical question>\n\n"
        f"Or if no clarification needed:\n"
        f"NO_CLARIFICATION_NEEDED"
    )
    response = await complete_llm(_GATE_SYSTEM, user, max_tokens=512)
    if "NO_CLARIFICATION_NEEDED" in response or not response.strip():
        return []
    questions = []
    for line in response.splitlines():
        m = re.match(r"CONSULT:\s*(\w+)\s*\|\s*(.+)", line.strip())
        if m:
            target   = m.group(1).strip().lower()
            question = m.group(2).strip()
            if target in ("architect",) and question:
                questions.append({"target": target, "question": question})
        if len(questions) >= 2:
            break
    return questions


class DevLeadAgent(BaseA2AAgent):
    def __init__(self):
        super().__init__(CARD)
        self._self_register()

    def _self_register(self):
        @self.app.on_event("startup")
        async def _register():
            for _ in range(5):
                try:
                    async with httpx.AsyncClient(timeout=3) as c:
                        await c.post(f"{REGISTRY_URL}/register",
                                     json={"card": CARD.model_dump()})
                    return
                except Exception:
                    time.sleep(1)

    async def handle_send(self, req: SendTaskRequest, task: Task) -> Task:
        skill = req.skillId or ""
        if skill == "answer-clarification":
            question = req.message.text()
            sys_prompt = (
                "You are a Roche Developer Lead. A colleague is asking for clarification "
                "about the Technical Design Specification you produced. Give a specific, "
                "actionable technical answer in 3-5 sentences. No preamble."
            )
            answer = await complete_llm(sys_prompt, f"Question: {question}")
            return self.make_completed_task(task, answer)
        raise NotImplementedError(f"Skill '{skill}' does not support non-streaming send")

    async def handle_stream(self, req: SendTaskRequest, task: Task):
        yield status_event("working")

        payload = req.message.data() or {}
        isag_json = payload.get("isag_json", "") or payload.get("isag", "")
        if isinstance(isag_json, dict):
            isag_json = json.dumps(isag_json)
        clarification_answers = payload.get("clarification_answers", [])

        # Clarification gate — only on first call (history has exactly 1 message)
        if len(task.history) == 1 and not clarification_answers:
            questions = await _check_clarifications(isag_json)
            if questions:
                task.status = TaskStatus(state=TaskState.INPUT_REQUIRED)
                self.tasks[task.id] = task
                yield input_required_event(questions)
                return   # SSE stream ends; orchestrator will resume with answers

        # Build context (include clarification answers if any)
        extra = ""
        if clarification_answers:
            extra = "\n\nClarifications from the Architect:\n" + "\n\n".join(
                f"Q: {qa['question']}\nA: {qa['answer']}" for qa in clarification_answers
            )

        system = _tds_system()
        user   = f"Convert this ISAG into a Technical Design Specification:\n\n{isag_json}{extra}"

        full_text = ""
        async for chunk in stream_llm(system, user):
            yield chunk_event(chunk)
            full_text += chunk

        tds_json_str = _clean_json(full_text)
        try:
            validated = TechnicalDesignSpec.model_validate_json(tds_json_str)
            tds_dict  = validated.model_dump()
        except Exception:
            tds_dict = json.loads(tds_json_str) if tds_json_str else {}

        task.status = TaskStatus(state=TaskState.COMPLETED)
        task.artifacts = [Artifact(parts=[DataPart(data=tds_dict)])]
        self.tasks[task.id] = task

        yield artifact_event(tds_dict, name="tds")
        yield completed_event({"tds": tds_dict})


_agent_instance = DevLeadAgent()
app: FastAPI = _agent_instance.app
