"""Architect Agent — generates ISAG from FSD + CSV, answers clarifications."""
from __future__ import annotations

import json
import re
import time

import httpx
from fastapi import FastAPI

from ..base_agent import BaseA2AAgent
from ..llm import stream_llm, complete_llm
from ..models import (
    AgentCard, AgentSkill, SendTaskRequest, Task, TaskState, TaskStatus,
    TextPart, DataPart, Artifact,
    status_event, chunk_event, artifact_event, completed_event, error_event,
)
from schemas.pipeline import ISAGDocument

PORT = 8101
REGISTRY_URL = "http://localhost:8105"

CARD = AgentCard(
    name="Architect Agent",
    description="Senior Integration Architect — analyses FSD and CSV mapping to produce an ISAG with gap analysis, API reuse recommendations, and 3-layered architecture design.",
    url=f"http://localhost:{PORT}",
    skills=[
        AgentSkill(
            id="generate-isag",
            name="Generate ISAG",
            description="Produce an Integration Solution Architecture Guide from a Functional Specification Document and field-mapping CSV.",
            inputModes=["data"],
            outputModes=["data"],
            tags=["architecture", "isag", "gap-analysis"],
        ),
        AgentSkill(
            id="answer-clarification",
            name="Answer Clarification",
            description="Answer technical questions from downstream agents about the ISAG.",
            inputModes=["text"],
            outputModes=["text"],
            tags=["clarification"],
        ),
    ],
)


def _clean_json(text: str) -> str:
    text = text.strip()
    if text.startswith("```json"):
        text = text[7:]
    elif text.startswith("```"):
        text = text[3:]
    if text.endswith("```"):
        text = text[:-3]
    text = text.strip()
    if text.startswith("{") or text.startswith("["):
        return text
    start = text.find("{")
    if start != -1:
        depth = 0
        for i, ch in enumerate(text[start:], start):
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    candidate = text[start: i + 1]
                    try:
                        json.loads(candidate)
                        return candidate
                    except json.JSONDecodeError:
                        break
    return text


def _build_system_prompt() -> str:
    schema_json = json.dumps(ISAGDocument.model_json_schema(), indent=2)
    return (
        "You are a Senior Integration Architect. Analyse the uploaded Functional Specification "
        "Document (FSD) and Mapping CSV. Identify requirement gaps, construct a professional "
        "clarification email, recommend reusable APIs from Anypoint Exchange, and draft a "
        "3-layered API structure (Experience, Process, System).\n\n"
        "CRITICAL: Output ONLY valid JSON adhering strictly to this JSON Schema:\n"
        + schema_json
    )


class ArchitectAgent(BaseA2AAgent):
    def __init__(self):
        super().__init__(CARD)
        self._self_register()

    def _self_register(self):
        @self.app.on_event("startup")
        async def _register():
            for _ in range(5):
                try:
                    async with httpx.AsyncClient(timeout=3) as c:
                        await c.post(f"{REGISTRY_URL}/register",
                                     json={"card": CARD.model_dump()})
                    return
                except Exception:
                    time.sleep(1)

    async def handle_send(self, req: SendTaskRequest, task: Task) -> Task:
        """Non-streaming — used for answer-clarification skill."""
        skill = req.skillId or ""
        if skill == "answer-clarification":
            question = req.message.text()
            sys_prompt = (
                "You are a Senior Integration Architect. A colleague is asking for clarification "
                "about architectural decisions you made. Give a specific, actionable technical "
                "answer in 3-5 sentences. No preamble."
            )
            answer = await complete_llm(sys_prompt, f"Question: {question}")
            return self.make_completed_task(task, answer)
        raise NotImplementedError(f"Skill '{skill}' does not support non-streaming send")

    async def handle_stream(self, req: SendTaskRequest, task: Task):
        """SSE streaming — generate-isag skill."""
        yield status_event("working")

        payload = req.message.data() or {}
        fsd     = payload.get("fsd", "")
        csv     = payload.get("csv", "")
        anypoint_token = payload.get("anypoint_token", "")

        system = _build_system_prompt()
        user   = (
            f"Generate the Integration Solution Architecture Guide (ISAG) based on:\n\n"
            f"--- FSD DOCUMENT ---\n{fsd}\n\n"
            f"--- MAPPING CSV ---\n{csv}\n"
        )
        if anypoint_token:
            user += f"\nAnypoint token provided: {anypoint_token[:10]}... Perform real API reuse lookup."

        full_text = ""
        async for chunk in stream_llm(system, user):
            yield chunk_event(chunk)
            full_text += chunk

        isag_json = _clean_json(full_text)
        try:
            validated = ISAGDocument.model_validate_json(isag_json)
            isag_dict = validated.model_dump()
        except Exception:
            isag_dict = json.loads(isag_json) if isag_json else {}

        task.status = TaskStatus(state=TaskState.COMPLETED)
        task.artifacts = [Artifact(parts=[DataPart(data=isag_dict)])]
        self.tasks[task.id] = task

        yield artifact_event(isag_dict, name="isag")
        yield completed_event({"isag": isag_dict})


_agent_instance = ArchitectAgent()
app: FastAPI = _agent_instance.app
