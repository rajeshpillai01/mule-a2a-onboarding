"""
Orchestrator Agent — coordinates the full onboarding pipeline across all agents.
Streams pipeline_event dicts to the Streamlit UI.
Handles the clarification gate: routes input-required questions to upstream agents
and resumes the requesting agent with answers.
"""
from __future__ import annotations

import json
import os
import time
import uuid

import httpx
from fastapi import FastAPI

from ..base_agent import BaseA2AAgent
from ..client import A2AClient
from ..models import (
    AgentCard, AgentSkill, SendTaskRequest, Task, TaskState, TaskStatus,
    DataPart, Artifact,
    status_event, completed_event, error_event,
    pipeline_event, file_creating_event, file_created_event,
)

PORT = 8100
REGISTRY_URL  = "http://localhost:8105"
ARCHITECT_URL = "http://localhost:8101"
DEV_LEAD_URL  = "http://localhost:8102"
DEVELOPER_URL = "http://localhost:8103"
ONA_URL       = "http://localhost:8104"

WORKSPACE_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ISAG_PATH = os.path.join(WORKSPACE_ROOT, "isag_document.json")
DS_PATH   = os.path.join(WORKSPACE_ROOT, "technical_design_spec.json")

CARD = AgentCard(
    name="Orchestrator Agent",
    description="Pipeline orchestrator — coordinates Architect, Developer Lead, Developer, and Ona agents with full A2A clarification gate support.",
    url=f"http://localhost:{PORT}",
    skills=[
        AgentSkill(
            id="run-onboarding-pipeline",
            name="Run Onboarding Pipeline",
            description="Execute the full 3-step onboarding pipeline (ISAG → TDS → AGENTS.md) with inter-agent clarification.",
            inputModes=["data"],
            outputModes=["data"],
            tags=["pipeline", "orchestration"],
        ),
        AgentSkill(
            id="run-mule-generation",
            name="Run Mule 4 Code Generation",
            description="Trigger Ona to generate a complete Mule 4 project from AGENTS.md.",
            inputModes=["data"],
            outputModes=["file"],
            tags=["mule4", "generation"],
        ),
    ],
)

_AGENT_META = {
    "architect": {"name": "Architect Agent",   "emoji": "🏗",  "url": ARCHITECT_URL},
    "dev_lead":  {"name": "Developer Lead",    "emoji": "📋",  "url": DEV_LEAD_URL},
    "developer": {"name": "Developer (Ona)",   "emoji": "💡",  "url": DEVELOPER_URL},
    "ona":       {"name": "Ona Agent",         "emoji": "🤖",  "url": ONA_URL},
}

_URL_FOR_AGENT = {
    "architect": ARCHITECT_URL,
    "dev_lead":  DEV_LEAD_URL,
    "developer": DEVELOPER_URL,
}


async def _run_step_with_clarification(
    client: A2AClient,
    agent_key: str,
    agent_url: str,
    skill_id: str,
    payload: dict,
    upstream_agents: dict,           # {agent_key: url} available for clarification
    context_store: dict,             # {agent_key: their last artifact dict}
) -> tuple[dict, list]:
    """
    Stream a pipeline step. Handles the input-required / clarification gate.
    Returns (artifact_dict, list_of_pipeline_event_dicts).
    """
    events_out = []
    task_id    = str(uuid.uuid4())
    artifact   = {}

    def pe(event_type, content="", target=""):
        ev = pipeline_event(event_type, agent_key, content, target)
        events_out.append(ev)
        return ev

    pe("step_start", f"Starting {AGENT_META_get(agent_key)} step...")

    # First call
    message = client.data_message(payload)
    async for ev in client.send_subscribe(agent_url, message, task_id=task_id, skill_id=skill_id):

        if ev.get("type") == "chunk":
            pe("step_chunk", ev.get("text", ""))

        elif ev.get("type") == "artifact":
            artifact = ev.get("data") or {}

        elif ev.get("type") == "input_required":
            # ── Clarification gate ──────────────────────────────────────────
            questions = ev.get("questions", [])
            if questions:
                pe("dialogue_question", "", "__section__")

            clarification_answers = []
            for q in questions[:2]:
                target_key = q.get("target", "architect")
                question   = q.get("question", "")
                target_url = _URL_FOR_AGENT.get(target_key, ARCHITECT_URL)
                target_name = AGENT_META_get(target_key)

                pe("dialogue_question", question, target_key)

                # Stream the answer from the target agent
                answer_chunks = []
                pe_ans = pe("dialogue_answer_start", "", agent_key)
                # re-use target agent's context as the answering context
                ctx = context_store.get(target_key, {})
                ans_payload = {"question": question, "context": ctx}
                ans_task = await client.send_task(
                    target_url,
                    client.data_message(ans_payload),
                    skill_id="answer-clarification",
                )
                answer = ""
                if ans_task.artifacts:
                    for part in ans_task.artifacts[0].parts:
                        if hasattr(part, "text"):
                            answer = part.text
                            break
                        if hasattr(part, "data") and isinstance(part.data, str):
                            answer = part.data
                            break

                # Stream answer word by word for UI effect
                for word in answer.split():
                    pe("dialogue_answer_chunk", word + " ", agent_key)
                pe("dialogue_answer_done", answer, agent_key)
                clarification_answers.append({"question": question, "answer": answer})

            # Resume the agent with same task_id + answers appended to payload
            payload_with_answers = {**payload, "clarification_answers": clarification_answers}
            resume_message = client.data_message(payload_with_answers)
            pe("step_start", f"Resuming {AGENT_META_get(agent_key)} with clarifications...")

            async for ev2 in client.send_subscribe(
                agent_url, resume_message, task_id=task_id, skill_id=skill_id
            ):
                if ev2.get("type") == "chunk":
                    pe("step_chunk", ev2.get("text", ""))
                elif ev2.get("type") == "artifact":
                    artifact = ev2.get("data") or {}
                elif ev2.get("type") == "completed":
                    artifact = ev2.get("artifact", {}) or artifact
                elif ev2.get("type") == "error":
                    raise RuntimeError(ev2.get("message", "Agent error"))

        elif ev.get("type") == "completed":
            artifact = ev.get("artifact", {}) or artifact

        elif ev.get("type") == "error":
            raise RuntimeError(ev.get("message", "Agent error"))

    pe("step_done", json.dumps(artifact)[:200])
    return artifact, events_out


def AGENT_META_get(key: str) -> str:
    return _AGENT_META.get(key, {}).get("name", key)


class OrchestratorAgent(BaseA2AAgent):
    def __init__(self):
        super().__init__(CARD)
        self._self_register()

    def _self_register(self):
        @self.app.on_event("startup")
        async def _register():
            for _ in range(5):
                try:
                    async with httpx.AsyncClient(timeout=3) as c:
                        await c.post(f"{REGISTRY_URL}/register",
                                     json={"card": CARD.model_dump()})
                    return
                except Exception:
                    time.sleep(1)

    async def handle_stream(self, req: SendTaskRequest, task: Task):
        yield status_event("working")

        skill = req.skillId or "run-onboarding-pipeline"

        if skill == "run-mule-generation":
            async for ev in self._run_mule_generation(req, task):
                yield ev
            return

        # ── Full onboarding pipeline ─────────────────────────────────────────
        payload = req.message.data() or {}
        fsd            = payload.get("fsd", "")
        csv_content    = payload.get("csv", "")
        anypoint_token = payload.get("anypoint_token", "")

        client = A2AClient()
        context_store: dict = {}

        try:
            # ── STEP 1: Architect → ISAG ─────────────────────────────────────
            yield pipeline_event("step_start", "architect",
                                 "Analysing FSD & CSV to generate Integration Solution Architecture Guide...")

            isag_dict = {}
            isag_task_id = str(uuid.uuid4())
            arch_payload = {"fsd": fsd, "csv": csv_content, "anypoint_token": anypoint_token}

            async for ev in client.send_subscribe(
                ARCHITECT_URL,
                client.data_message(arch_payload),
                task_id=isag_task_id,
                skill_id="generate-isag",
            ):
                if ev.get("type") == "chunk":
                    yield pipeline_event("step_chunk", "architect", ev.get("text", ""))
                elif ev.get("type") == "artifact":
                    isag_dict = ev.get("data") or {}
                elif ev.get("type") == "completed":
                    isag_dict = ev.get("artifact", {}).get("isag", isag_dict)
                elif ev.get("type") == "error":
                    yield pipeline_event("step_done", "architect", f"Error: {ev.get('message')}")
                    return

            with open(ISAG_PATH, "w", encoding="utf-8") as f:
                json.dump(isag_dict, f, indent=2)
            context_store["architect"] = isag_dict
            yield pipeline_event("step_done", "architect", json.dumps(isag_dict)[:100] + "…")

            # ── STEP 2: Developer Lead → TDS (with clarification gate) ────────
            yield pipeline_event("step_start", "dev_lead",
                                 "Generating Technical Design Specification from ISAG...")

            dl_task_id = str(uuid.uuid4())
            dl_payload = {"isag_json": json.dumps(isag_dict)}
            tds_dict   = {}

            async for ev in self._stream_with_gate(
                client, "dev_lead", DEV_LEAD_URL, "generate-tds",
                dl_payload, dl_task_id, context_store,
            ):
                if ev.get("type") == "pipeline_event":
                    yield ev
                elif ev.get("type") == "artifact_ready":
                    tds_dict = ev.get("data", {})

            with open(DS_PATH, "w", encoding="utf-8") as f:
                json.dump(tds_dict, f, indent=2)
            context_store["dev_lead"] = tds_dict

            # ── STEP 3: Developer → AGENTS.md (with clarification gate) ───────
            yield pipeline_event("step_start", "developer",
                                 "Generating Mule 4 code & MUnit test instructions for Ona...")

            dev_task_id = str(uuid.uuid4())
            dev_payload = {"tds_json": json.dumps(tds_dict)}
            agents_md_dict = {}

            async for ev in self._stream_with_gate(
                client, "developer", DEVELOPER_URL, "generate-agents-md",
                dev_payload, dev_task_id, context_store,
            ):
                if ev.get("type") == "pipeline_event":
                    yield ev
                elif ev.get("type") == "artifact_ready":
                    agents_md_dict = ev.get("data", {})

            context_store["developer"] = agents_md_dict

        except Exception as e:
            yield pipeline_event("step_done", "orchestrator", f"Pipeline error: {e}")
            yield error_event(str(e))
            return

        task.status = TaskStatus(state=TaskState.COMPLETED)
        task.artifacts = [Artifact(parts=[DataPart(data=context_store)])]
        self.tasks[task.id] = task
        yield completed_event({"isag": isag_dict, "tds": tds_dict})

    async def _stream_with_gate(
        self,
        client: A2AClient,
        agent_key: str,
        agent_url: str,
        skill_id: str,
        payload: dict,
        task_id: str,
        context_store: dict,
    ):
        """
        Stream a step; handle input-required clarification gate.
        Yields pipeline_event dicts and one artifact_ready dict.
        """
        artifact = {}

        async for ev in client.send_subscribe(
            agent_url, client.data_message(payload),
            task_id=task_id, skill_id=skill_id,
        ):
            t = ev.get("type")

            if t == "chunk":
                yield pipeline_event("step_chunk", agent_key, ev.get("text", ""))

            elif t == "artifact":
                artifact = ev.get("data") or {}

            elif t == "input_required":
                questions = ev.get("questions", [])
                if questions:
                    yield pipeline_event("dialogue_question", agent_key, "", "__section__")

                clarification_answers = []
                for q in questions[:2]:
                    target_key  = q.get("target", "architect")
                    question    = q.get("question", "")
                    target_url  = _URL_FOR_AGENT.get(target_key, ARCHITECT_URL)

                    yield pipeline_event("dialogue_question", agent_key, question, target_key)
                    yield pipeline_event("dialogue_answer_start", target_key, "", agent_key)

                    ans_task = await client.send_task(
                        target_url,
                        client.text_message(question),
                        skill_id="answer-clarification",
                    )
                    answer = ""
                    if ans_task.artifacts:
                        for part in ans_task.artifacts[0].parts:
                            if hasattr(part, "text"):
                                answer = part.text
                                break

                    for word in answer.split():
                        yield pipeline_event("dialogue_answer_chunk", target_key,
                                             word + " ", agent_key)
                    yield pipeline_event("dialogue_answer_done", target_key, answer, agent_key)
                    clarification_answers.append({"question": question, "answer": answer})

                # Resume with answers
                resumed_payload = {**payload, "clarification_answers": clarification_answers}
                yield pipeline_event("step_start", agent_key,
                                     f"Resuming with {len(clarification_answers)} clarification(s)...")

                async for ev2 in client.send_subscribe(
                    agent_url, client.data_message(resumed_payload),
                    task_id=task_id, skill_id=skill_id,
                ):
                    t2 = ev2.get("type")
                    if t2 == "chunk":
                        yield pipeline_event("step_chunk", agent_key, ev2.get("text", ""))
                    elif t2 == "artifact":
                        artifact = ev2.get("data") or {}
                    elif t2 == "completed":
                        artifact = ev2.get("artifact", {}) or artifact
                    elif t2 == "error":
                        raise RuntimeError(ev2.get("message", "Agent error on resume"))

            elif t == "completed":
                artifact = ev.get("artifact", {}) or artifact

            elif t == "error":
                raise RuntimeError(ev.get("message", "Agent error"))

        yield pipeline_event("step_done", agent_key, "")
        yield {"type": "artifact_ready", "data": artifact}

    async def _run_mule_generation(self, req: SendTaskRequest, task: Task):
        """Delegate Mule 4 code generation to Ona Agent, forwarding all file events."""
        yield status_event("working")
        payload = req.message.data() or {}

        client = A2AClient()
        ona_task_id = str(uuid.uuid4())

        yield pipeline_event("step_start", "ona", "Executing AGENTS.md → writing Mule 4 files...")

        file_manifest = []
        async for ev in client.send_subscribe(
            ONA_URL,
            client.data_message(payload),
            task_id=ona_task_id,
            skill_id="generate-mule-project",
        ):
            t = ev.get("type")
            if t == "chunk":
                yield pipeline_event("step_chunk", "ona", ev.get("text", ""))
            elif t == "file_creating":
                yield file_creating_event(ev.get("path", ""))
            elif t == "file_created":
                p = ev.get("path", "")
                s = ev.get("size", 0)
                file_manifest.append({"path": p, "size": s})
                yield file_created_event(p, s)
            elif t in ("skill_prep_start", "skill_prep_done", "skill_prep_skip"):
                yield ev
            elif t == "completed":
                file_manifest = ev.get("artifact", {}).get("files", file_manifest)
            elif t == "error":
                yield error_event(ev.get("message", "Ona error"))
                return

        task.status = TaskStatus(state=TaskState.COMPLETED)
        task.artifacts = [Artifact(parts=[DataPart(data={"files": file_manifest})])]
        self.tasks[task.id] = task

        yield pipeline_event("step_done", "ona", f"{len(file_manifest)} files written")
        yield completed_event({"files": file_manifest})


_agent_instance = OrchestratorAgent()
app: FastAPI = _agent_instance.app
