"""Pydantic schemas for structured LLM output at each pipeline step."""
from typing import List, Optional
from pydantic import BaseModel, Field


# ── Architect output ─────────────────────────────────────────────────────────

class GapFinding(BaseModel):
    category: str    = Field(..., description="E.g. 'Data Access', 'Transformation Constraint'")
    discrepancy: str = Field(..., description="Specific gap between FSD and Mapping CSV")
    severity: str    = Field(..., description="High | Medium | Low")

class StagedClarificationEmail(BaseModel):
    recipient: str = Field(..., description="Team or role responsible for resolving gaps")
    subject: str   = Field(..., description="Professional subject line including interface ID")
    body: str      = Field(..., description="Questions to resolve, professionally worded")

class ReusableApiRecommendation(BaseModel):
    api_name: str            = Field(..., description="Name of existing API in Anypoint Exchange")
    api_type: str            = Field(..., description="System API | Process API | Experience API")
    reuse_justification: str = Field(..., description="Why this API fits the current requirement")

class ApiLayeringArchitecture(BaseModel):
    experience_layer: str = Field(..., description="Consumer-facing APIs")
    process_layer: str    = Field(..., description="Orchestration and business-rules APIs")
    system_layer: str     = Field(..., description="APIs shielding backend systems")

class ISAGDocument(BaseModel):
    project_name: str                             = Field(..., description="Title of the integration initiative")
    discovery_summary: str                        = Field(..., description="Architectural narrative of the integration flow")
    gaps: List[GapFinding]                        = Field(..., description="Identified requirements discrepancies")
    staged_email: StagedClarificationEmail        = Field(..., description="Clarification email draft")
    api_reuse_analysis: List[ReusableApiRecommendation] = Field(..., description="API reuse options")
    layered_architecture: ApiLayeringArchitecture = Field(..., description="3-layered API structure map")


# ── Developer Lead output ────────────────────────────────────────────────────

class EndpointDefinition(BaseModel):
    path: str          = Field(..., description="URI endpoint, e.g. /api/v1/orders")
    method: str        = Field(..., description="POST | GET | PUT | DELETE")
    description: str   = Field(..., description="Functional purpose")
    request_type: str  = Field(..., description="Reference to request schema")
    response_type: str = Field(..., description="Success and error response types")

class SecurityPolicy(BaseModel):
    policy_type: str = Field(..., description="Client ID Enforcement | OAuth 2.0 | Basic Auth")
    applied_to: str  = Field(..., description="Which layer or endpoint this applies to")

class TechnicalDesignSpec(BaseModel):
    title: str                              = Field(..., description="Technical Design Spec title")
    isag_reference_id: str                  = Field(..., description="Reference ID matching the ISAG")
    endpoints: List[EndpointDefinition]     = Field(..., description="REST interface definitions")
    dataweave_rules_summary: str            = Field(..., description="DataWeave transformation summary")
    security_requirements: List[SecurityPolicy] = Field(..., description="Security policies")
    error_handling_strategy: str            = Field(..., description="Global error behaviour rules")


# ── Developer/Ona output (becomes AGENTS.md) ─────────────────────────────────

class OnaInstructionSet(BaseModel):
    target_project_name: str        = Field(..., description="MuleSoft project workspace name")
    project_directories: List[str]  = Field(..., description="Directories to generate")
    raml_scaffolding_marching_orders: str     = Field(..., description="RAML 1.0 spec generation rules")
    mule_xml_generation_marching_orders: str  = Field(..., description="Mule 4 XML flow generation steps")
    munit_testing_marching_orders: str        = Field(..., description="MUnit test coverage rules")
